// Gomoku.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "application.h"

int main(int, char**)
{
	{
		Application app;
		app.run();
	}
	return 0;
}